package newcloud;

public class helloworld {
    public static void main(String[] args) {
        System.out.printf("HELLO WORLD\n");
    }
}
